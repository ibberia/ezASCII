#!/usr/bin/env sh
# Run ezASCII.rb with the system Ruby, forwarding all arguments.

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
RUBY_BIN="${RUBY:-ruby}"

exec "$RUBY_BIN" "$SCRIPT_DIR/ezASCII.rb" "$@"